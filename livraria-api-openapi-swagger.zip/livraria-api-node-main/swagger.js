const swaggerDocument = {
  openapi: '3.0.3',
  info: {
    title: 'API Livros e Autores',
    version: '1.0.0',
    description: 'API REST de livros, autores, comentários e autenticação. Cadastro público cria usuários USER; operações de criação de livros e autores exigem perfil ADMIN.'
  },
  servers: [{ url: 'http://localhost:3000', description: 'Servidor local' }],
  tags: [
    { name: 'Autenticação', description: 'Cadastro e login' },
    { name: 'Livros', description: 'Consulta e cadastro de livros' },
    { name: 'Autores', description: 'Cadastro de autores' },
    { name: 'Comentários', description: 'Comentários em livros' }
  ],
  components: {
    securitySchemes: {
      bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT', description: 'Faça login em /api/v1/auth/login, copie o campo token e informe aqui. O prefixo Bearer é inserido pela interface.' }
    },
    schemas: {
      Erro: { type: 'object', properties: { erro: { type: 'string', example: 'Livro não localizado.' } }, required: ['erro'] },
      UsuarioCadastro: { type: 'object', required: ['nome', 'email', 'senha'], properties: { nome: { type: 'string', example: 'Ana Souza' }, email: { type: 'string', format: 'email', example: 'ana@email.com' }, senha: { type: 'string', format: 'password', minLength: 8, example: 'SenhaForte123' } } },
      Usuario: { type: 'object', properties: { id: { type: 'integer', example: 1729000000000 }, nome: { type: 'string', example: 'Ana Souza' }, email: { type: 'string', format: 'email', example: 'ana@email.com' }, role: { type: 'string', enum: ['USER', 'ADMIN'], example: 'USER' } } },
      Login: { type: 'object', required: ['email', 'senha'], properties: { email: { type: 'string', format: 'email', example: 'leitor@gmail.com' }, senha: { type: 'string', format: 'password', example: 'Leitor123' } } },
      LoginResposta: { type: 'object', properties: { usuario: { type: 'object', properties: { id: { type: 'integer', example: 2 }, nome: { type: 'string', example: 'Leitor' }, role: { type: 'string', example: 'USER' } } }, token: { type: 'string', example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' } } },
      AutorEntrada: { type: 'object', required: ['nome'], properties: { nome: { type: 'string', example: 'Conceição Evaristo' }, nacionalidade: { type: 'string', example: 'Brasileira' } } },
      Autor: { type: 'object', properties: { id: { type: 'integer', example: 1729000000000 }, nome: { type: 'string', example: 'Conceição Evaristo' }, nacionalidade: { type: 'string', example: 'Brasileira' } } },
      LivroEntrada: { type: 'object', required: ['titulo', 'autor_id'], properties: { titulo: { type: 'string', example: 'Olhos d’Água' }, ano: { type: 'integer', example: 2014 }, autor_id: { type: 'integer', example: 1 } } },
      Livro: { type: 'object', properties: { id: { type: 'integer', example: 1729000000000 }, titulo: { type: 'string', example: 'Dom Casmurro' }, ano: { type: 'integer', example: 1899 }, autor_id: { type: 'integer', example: 1 }, autor_nome: { type: 'string', example: 'Machado de Assis' }, comentarios: { type: 'array', items: { $ref: '#/components/schemas/Comentario' } } } },
      ComentarioEntrada: { type: 'object', required: ['texto'], properties: { texto: { type: 'string', minLength: 1, example: 'Uma leitura marcante.' } } },
      Comentario: { type: 'object', properties: { id: { type: 'integer', example: 1729000000000 }, autor_nome: { type: 'string', example: 'Leitor' }, texto: { type: 'string', example: 'Uma leitura marcante.' } } }
    }
  },
  paths: {
    '/api/v1/livros': {
      get: { tags: ['Livros'], summary: 'Listar livros', description: 'Consulta pública de todos os livros cadastrados.', responses: { '200': { description: 'Lista de livros', content: { 'application/json': { schema: { type: 'array', items: { $ref: '#/components/schemas/Livro' } }, example: [{ id: 1, titulo: 'Dom Casmurro', ano: 1899, autor_id: 1, comentarios: [], autor_nome: 'Machado de Assis' }] } } }, '500': { description: 'Erro interno', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' } } } } } },
      post: { tags: ['Livros'], summary: 'Cadastrar livro (ADMIN)', description: 'Cria um livro. Requer token JWT de usuário com perfil ADMIN e autor_id existente.', security: [{ bearerAuth: [] }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/LivroEntrada' } } } }, responses: { '201': { description: 'Livro criado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Livro' } } } }, '400': { description: 'Título ou autor_id ausente', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' }, example: { erro: 'O título e o autor_id são obrigatórios.' } } } }, '401': { description: 'Token ausente ou inválido' }, '403': { description: 'Perfil sem permissão' }, '404': { description: 'Autor não encontrado' } } }
    },
    '/api/v1/livros/{id}': { get: { tags: ['Livros'], summary: 'Consultar livro por ID', description: 'Consulta pública de um livro específico.', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' }, example: 1 }], responses: { '200': { description: 'Livro encontrado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Livro' } } } }, '404': { description: 'Livro não encontrado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' }, example: { erro: 'Livro não localizado.' } } } } } } },
    '/api/v1/auth/register': { post: { tags: ['Autenticação'], summary: 'Cadastrar usuário', description: 'Cria uma conta pública com perfil USER. A senha é armazenada usando BCrypt; não é possível definir ADMIN por esta rota.', requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/UsuarioCadastro' } } } }, responses: { '201': { description: 'Usuário cadastrado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Usuario' } } } }, '400': { description: 'Campos obrigatórios ausentes', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' } } } }, '422': { description: 'Dados inválidos' }, '409': { description: 'E-mail já cadastrado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' } } } } } } },
    '/api/v1/auth/login': { post: { tags: ['Autenticação'], summary: 'Entrar e obter JWT', description: 'Valida e-mail e senha e retorna token JWT válido por 2 horas. Copie token para usar Authorize.', requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Login' } } } }, responses: { '200': { description: 'Autenticação concluída', content: { 'application/json': { schema: { $ref: '#/components/schemas/LoginResposta' } } } }, '400': { description: 'E-mail ou senha ausente', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' } } } }, '422': { description: 'Dados inválidos' }, '401': { description: 'Credenciais inválidas', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' }, example: { erro: 'Credenciais inválidas.' } } } } } } },
    '/api/v1/livros/{id}/comentarios': { post: { tags: ['Comentários'], summary: 'Comentar em um livro', description: 'Adiciona comentário vinculado ao usuário autenticado. Permitido para USER e ADMIN.', security: [{ bearerAuth: [] }], parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' }, example: 1 }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/ComentarioEntrada' } } } }, responses: { '201': { description: 'Comentário criado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Comentario' } } } }, '400': { description: 'Texto ausente ou vazio', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' } } } }, '422': { description: 'Dados inválidos' }, '401': { description: 'Token ausente, expirado ou inválido' }, '404': { description: 'Livro não encontrado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' } } } } } } },
    '/api/v1/autores': { post: { tags: ['Autores'], summary: 'Cadastrar autor (ADMIN)', description: 'Cria autor. Requer token JWT com perfil ADMIN.', security: [{ bearerAuth: [] }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/AutorEntrada' } } } }, responses: { '201': { description: 'Autor criado', content: { 'application/json': { schema: { $ref: '#/components/schemas/Autor' } } } }, '400': { description: 'Nome obrigatório', content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' } } } }, '422': { description: 'Dados inválidos' }, '401': { description: 'Token ausente ou inválido' }, '403': { description: 'Perfil sem permissão' } } } }
  }
};

module.exports = swaggerDocument;
